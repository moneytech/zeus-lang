import os
from pathlib import Path

class BuildPathNotString(BaseException):
    """ BuildPath path must be a string """
    pass

class BuildPathExists(BaseException):
    """ BuildPath path must not be pointed at an existing path to create it """
    pass

class BuildPathDoesNotExist(BaseException):
    """ BuildPath path must be pointed at an existing file or directory """
    pass

class BuildPathNotAFile(BaseException):
    """ BuildPath was expected to be an existing file """

class BuildPath:
    def __init__(self, path):
        if isinstance(path, Path):
            self.path = path
        elif type(path) is str:
            self.path = Path(path)
        else:
            raise BuildPathNotString

    def exists(self):
        return os.path.exists(str(self.path))

    def is_file(self):
        return self.exists() and self.path.is_file()

    def is_directory(self):
        return self.exists() and self.path.is_dir()

    def create(self):
        if not self.exists():
            os.makedirs(str(self.path))
        else:
            raise BuildPathExists

    def split_filename(self):
        if not self.exists():
            raise BuildPathDoesNotExist
        else:
            if self.is_file():
                return os.path.splitext(str(self.path))
            else:
                raise BuildPathNotAFile

    def filename(self):
        name, ext = self.split_filename()
        return name

    def extension(self):
        name, ext = self.split_filename()
        return ext

    def split_head(self):
        if len(self.path.parts) > 1:
            # Return self.path top most directory, separately from what remains
            # Useful for directory mirroring where the topmost is not desired
            return Path(*self.path.parts[:1]), Path(*self.path.parts[1:])
        else:
            return path

    def split_tail(self):
        if len(self.path.parts) > 1:
            # Return the self.path separate from the deepest directory
            # Useful for directory traversal where "up one level" is desired
            return Path(*self.path.parts[:-1]), Path(*self.path.parts[-1:])
        else:
            return path

    def head(self):
        head, body = self.split_head()
        return head

    def tail(self):
        body, tail = self.split_tail()
        return tail

    def headless(self):
        head, body = self.split_head()
        return body

    def tailless(self):
        body, tail = self.split_tail()
        return body
