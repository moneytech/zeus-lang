import re
from pathlib import Path
from enum import Enum

class NotPathType(BaseException):
    """ Raised when a passed path isn't of pathlib.Path type """
    pass

class NotCrawlStrategyType(BaseException):
    """ Raised when a passed strategy isn't an integer """
    pass

class NotCrawlActionType(BaseException):
    """ Raised when a passed crawl action isn't an integer """
    pass

class MatchExpressionNotString(BaseException):
    """ Raised when a match expression is not a string """
    pass

class CrawlStrategy(Enum):
    SHALLOW, RECURSIVE, NO_LOCK = range(3)

class CrawlAction(Enum):
    ALL_PATHS, FILES, DIRECTORIES, PATTERN = range(4)

class Crawler:
    def __init__(self, path, strategy=CrawlStrategy.SHALLOW, action=CrawlAction.ALL_PATHS, match=None):
        self.set_path(path)
        self.set_strategy(strategy)
        self.set_action(action)
        if match is not None:
            self.set_match_expression(match)
        self.crawled_paths = None
        self.crawled_files = None
        self.crawled_directories = None
        self.crawled_matched_paths = None

    def set_path(self, path):
        if not (isinstance(path, Path) or type(path) is str):
            raise NotPathType
        self.root_path = Path(path)

    def set_strategy(self, strategy):
        if not (isinstance(strategy, int) or isinstance(strategy, Enum)):
            raise NotCrawlStrategyType
        self.strategy = strategy

    def set_action(self, action):
        if not (isinstance(action, int) or isinstance(action, Enum)):
            raise NotCrawlActionType
        self.action = action

    def set_match_expression(self, expression):
        if type(expression) is not str:
            raise MatchExpressionNotString
        self.match_expression = re.compile(expression)

    def __quick_flatten(self, list):
        return [item for sublist in list for item in sublist]

    def __flatten(self, list_to_flatten):
        flattened = []
        for item in list_to_flatten:
            if type(item) is list:
                subitems = self.__flatten(item)
                for sub in subitems:
                    flattened.append(sub)
            else:
                flattened.append(item)
        return flattened

    def __directories_in(self, path_string, recursive=False):
        result = []
        dirs = [x for x in Path(path_string).iterdir() if x.is_dir()]
        in_subdirs = []
        if recursive:
            for dir in dirs:
                dirs_in_subdir = self.__directories_in(dir, recursive)
                for d in dirs_in_subdir:
                    if type(d) is not list:
                        in_subdirs.append(d)
        if len(in_subdirs) > 0:
            result = self.__flatten([dirs, in_subdirs])
        else:
            result = dirs
        return result

    def __files_in(self, path_string, recursive=False):
        result = []
        files = [x for x in Path(path_string).iterdir() if x.is_file()]
        in_subdirs = []
        if recursive:
            dirs = self.__directories_in(path_string, False)
            for dir in dirs:
                in_subdirs.append(self.__files_in(dir, recursive))
        if len(in_subdirs) > 0:
            result = self.__flatten([files, in_subdirs])
        else:
            result = files
        return result

    def crawl(self):
        self.crawled_paths = []
        self.crawled_files = []
        self.crawled_directories = []
        self.crawled_matched_paths = []
        # Determine if recursive based on strategy
        is_recursive = True if self.strategy in (CrawlStrategy.RECURSIVE,
            CrawlStrategy.NO_LOCK) else False
        # Get all files
        if self.action != CrawlAction.DIRECTORIES:
            self.crawled_files = self.__files_in(self.root_path, is_recursive)
        # Get all directories
        if self.action != CrawlAction.FILES:
            self.crawled_directories = self.__directories_in(self.root_path, is_recursive)
        # Get all paths (directories and files together)
        self.crawled_paths = self.__flatten([self.crawled_files, self.crawled_directories])
        # If pattern matching is enabled for this crawler
        if self.action is CrawlAction.PATTERN:
            # If crawler.match_expression is valid
            if self.match_expression is not None:
                for path in self.crawled_paths:
                    if self.match_expression.search(str(path)):
                        self.crawled_matched_paths.append(path)

    def paths(self):
        return self.crawled_paths

    def files(self):
        return self.crawled_files

    def directories(self):
        return self.crawled_directories

    def matches(self):
        return self.crawled_matched_paths
