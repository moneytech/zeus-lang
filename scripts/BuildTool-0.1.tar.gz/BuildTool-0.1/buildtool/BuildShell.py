import re, os

class BuildShellSequenceMustBeListOfStrings(BaseException):
    """ BuildShell sequence must be of list of strings type """
    pass

class BuildShell:
    def __init__(self, command_sequence=None):
        self.name = name
        self.sequence(command_sequence)
        self.output = []

    def substitute(self, command, *args):
        """ Substitutes each integer preceded by a dollar sign in command string
        for each argument passed in args (e.g.):
            substitute('gcc -c $1 -o $2.o $3', 'file.c', 'file', '-g')
                returns:
            'gcc -c file.c -o file.o -g'
        """
        transposed_command = str(command)
        argument_iterator = 1
        for arg in args:
            if type(arg) is list:
                list_arg = ''
                if len(arg) > 0:
                    for a in arg:
                        list_arg = list_arg + ' ' + str(a)
                    transposed_command = transposed_command.replace('$' + str(argument_iterator), list_arg)
            else:
                transposed_command = transposed_command.replace('$' + str(argument_iterator), str(arg))
            argument_iterator += 1
        return re.sub('$.', '', transposed_command)

    def execute_command(self, command):
        return subprocess.run(command, stdout=subprocess.PIPE).stdout

    def sequence(self, command_sequence):
        if command_sequence is not None:
            valid_sequence = True
            if type(command_sequence) is list:
                if len(command_sequence) > 0:
                    for item in list:
                        if not type(item) is str:
                            valid_sequence = False
                    else:
                        valid_sequence = False
            if valid_sequence:
                self.command_sequence = command_sequence
            else:
                raise BuildShellSequenceMustBeListOfStrings
        else:
            self.command_sequence = None

    def execute_sequence(self):
        if self.command_sequence is not None:
            for command in self.command_sequence:
                self.output.append(self.execute_command(command))
        else:
            self.output = ["Nothing was executed, empty sequence"]
        return self.output

    def print_output(self):
        for line in self.output:
            print(line)
