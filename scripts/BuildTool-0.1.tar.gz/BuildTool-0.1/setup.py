from distutils.core import setup

setup(
    name='BuildTool',
    version='0.1',
    packages=['buildtool','examples','spec'],
    license='MIT',
    long_description=open('README.md').read(),
)
